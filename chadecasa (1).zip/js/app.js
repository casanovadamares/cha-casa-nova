(function () {
  "use strict";

  var STEPS = [
    { id: "endereco",  label: "Local" },
    { id: "presentes", label: "Presentes" },
    { id: "bingo",     label: "Bingo" },
    { id: "confirmar", label: "Confirmar" },
    { id: "lembrete",  label: "Lembrete" }
  ];
  var KEY = "cha-damaris-lucas-confirmou";

  var screens = document.querySelectorAll(".screen");
  var tabbar = document.getElementById("tabbar");
  var tabs = tabbar.querySelectorAll("a[data-tab]");
  var stepbar = document.getElementById("stepbar");
  var sbBack = document.getElementById("sb-back");
  var sbNext = document.getElementById("sb-next");
  var sheet = document.getElementById("sheet");
  var toastEl = document.getElementById("toast");
  var toastTimer;
  var mapLoaded = false;
  var waClicked = false;

  /* ---------- Guarda "já enviei" só neste aparelho (sem servidor, sem cadastro) ---------- */
  function readFlag() { try { return localStorage.getItem(KEY) === "1"; } catch (e) { return false; } }
  function saveFlag() { try { localStorage.setItem(KEY, "1"); } catch (e) { /* ok */ } }
  var confirmed = readFlag();

  /* ---------- Ícones ---------- */
  function icon(id, cls) {
    return '<svg' + (cls ? ' class="' + cls + '"' : "") + '><use href="#' + id + '"/></svg>';
  }

  /* ---------- Navegação por hash ---------- */
  function coverId() { return COVER_STYLE === "casa" ? "capa" : "capa-classica"; }

  function currentId() {
    var id = (location.hash || "").replace("#", "");
    if (id === "capa" || id === "capa-classica") return coverId();
    var el = document.getElementById(id);
    return el && el.classList.contains("screen") ? id : coverId();
  }

  function stepIndex(id) {
    for (var i = 0; i < STEPS.length; i++) if (STEPS[i].id === id) return i;
    return -1;
  }

  function show(id) {
    var active = null;
    screens.forEach(function (s) {
      var on = s.id === id;
      s.classList.toggle("active", on);
      if (on) active = s;
    });

    var idx = stepIndex(id);
    var tabsOff = active && active.getAttribute("data-tabs") === "off";
    tabbar.classList.toggle("show", !tabsOff);
    stepbar.classList.toggle("show", idx >= 0);

    var tabId = id === "havan" ? "presentes" : id;
    tabs.forEach(function (a) { a.classList.toggle("on", a.getAttribute("data-tab") === tabId); });

    if (idx >= 0) { renderProgress(active, idx); setupStepbar(idx); }
    if (id === "endereco") loadMap();
    if (id === "inicio") refreshResume();
    if (id === "lembrete") refreshReminder();
    closeSheet();
    window.scrollTo(0, 0);
  }

  window.addEventListener("hashchange", function () { show(currentId()); });

  /* ---------- Barra de progresso ---------- */
  function renderProgress(screen, idx) {
    var el = screen.querySelector("[data-progress]");
    if (!el) return;
    var pct = Math.round(((idx + 1) / STEPS.length) * 100);
    var dots = STEPS.map(function (s, i) {
      var cls = i < idx ? "dot done" : i === idx ? "dot now" : "dot";
      return '<a class="' + cls + '" href="#' + s.id + '"><b>' + (i < idx ? "✓" : i + 1) + "</b>" + s.label + "</a>";
    }).join("");
    el.innerHTML =
      '<p class="ptxt">Passo <strong>' + (idx + 1) + "</strong> de " + STEPS.length + "</p>" +
      '<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '"><i style="width:' + pct + '%"></i></div>' +
      '<div class="dots">' + dots + "</div>";
  }

  /* ---------- Botões Voltar / Continuar ---------- */
  function setupStepbar(idx) {
    var prev = idx === 0 ? coverId() : STEPS[idx - 1].id;
    sbBack.setAttribute("href", "#" + prev);
    sbBack.textContent = idx === 0 ? "Início" : "Voltar";
    var last = idx === STEPS.length - 1;
    sbNext.setAttribute("href", last ? "#obrigada" : "#" + STEPS[idx + 1].id);
    sbNext.innerHTML = (last ? "Concluir " : "Continuar ") + icon(last ? "i-heart" : "i-right");
  }

  sbNext.addEventListener("click", function (e) {
    if (currentId() === "confirmar" && !confirmed) {
      e.preventDefault();
      openSheet();
    }
  });

  /* ---------- Pergunta "você enviou a mensagem?" ---------- */
  function openSheet() { sheet.hidden = false; document.getElementById("sheet-yes").focus(); }
  function closeSheet() { sheet.hidden = true; }

  document.getElementById("sheet-no").addEventListener("click", closeSheet);
  document.getElementById("sheet-yes").addEventListener("click", function () {
    confirmed = true;
    saveFlag();
    closeSheet();
    toast("Obrigada por confirmar! 💛");
    setTimeout(function () { location.hash = "lembrete"; }, 800);
  });
  sheet.addEventListener("click", function (e) { if (e.target === sheet) closeSheet(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeSheet(); });

  // Ao voltar do WhatsApp, pergunta se a mensagem foi enviada e avança sozinho
  function backFromWhats() {
    if (!waClicked || document.hidden) return;
    if (currentId() === "confirmar" && !confirmed) {
      waClicked = false;
      setTimeout(openSheet, 400);
    }
  }
  document.addEventListener("visibilitychange", backFromWhats);
  window.addEventListener("focus", backFromWhats);

  /* ---------- Aviso rápido ---------- */
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("show"); }, 2600);
  }

  /* ---------- Cartão "continuar" no início ---------- */
  function refreshResume() {
    var a = document.getElementById("resume");
    var t = document.getElementById("resume-title");
    var s = document.getElementById("resume-sub");
    if (confirmed) {
      a.setAttribute("href", "#lembrete");
      t.textContent = "Mensagem de confirmação enviada ✓";
      s.textContent = "Toque para salvar o lembrete do chá";
    } else {
      a.setAttribute("href", "#endereco");
      t.textContent = "Seguir o passo a passo";
      s.textContent = "Em 5 passos rápidos você confirma sua presença";
    }
  }

  /* ---------- Endereço ---------- */
  var q = encodeURIComponent(EVENT_ADDRESS);
  var mapsLink = "https://www.google.com/maps/search/?api=1&query=" + q;
  document.getElementById("btn-maps").href = mapsLink;
  document.getElementById("btn-route").href = "https://www.google.com/maps/dir/?api=1&destination=" + q;

  function loadMap() {
    if (mapLoaded) return;
    mapLoaded = true;
    document.getElementById("map").src = "https://www.google.com/maps?q=" + q + "&output=embed";
  }

  function fallbackCopy(text) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  document.getElementById("btn-copy").addEventListener("click", function () {
    function done(ok) { toast(ok ? "Endereço copiado!" : "Não foi possível copiar."); }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(EVENT_ADDRESS).then(function () { done(true); }, function () { done(fallbackCopy(EVENT_ADDRESS)); });
    } else {
      done(fallbackCopy(EVENT_ADDRESS));
    }
  });

  /* ---------- Presentes ---------- */
  var chipsEl = document.getElementById("chips");
  var tilesEl = document.getElementById("tiles");
  var havanCats = document.getElementById("havan-cats");
  var filter = "todos";

  function renderChips() {
    var items = [{ id: "todos", chip: "Todos" }].concat(GIFT_CATEGORIES);
    chipsEl.innerHTML = "";
    items.forEach(function (c) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "chip" + (c.id === filter ? " on" : "");
      b.textContent = c.chip;
      b.addEventListener("click", function () { filter = c.id; renderChips(); renderTiles(); });
      chipsEl.appendChild(b);
    });
  }

  function renderTiles() {
    tilesEl.innerHTML = "";
    GIFT_CATEGORIES.forEach(function (c) {
      if (filter !== "todos" && filter !== c.id) return;
      var t = document.createElement("button");
      t.type = "button";
      t.className = "tile";
      t.setAttribute("aria-expanded", "false");
      t.innerHTML =
        '<span class="art">' + icon(c.icon) + "</span>" +
        '<span class="name"><span>' + c.name + "</span>" + icon("i-right") + "</span>" +
        '<span class="ideas">' + c.ideas + "</span>";
      t.addEventListener("click", function () {
        t.setAttribute("aria-expanded", t.getAttribute("aria-expanded") === "true" ? "false" : "true");
      });
      tilesEl.appendChild(t);
    });
  }

  function renderHavanCats() {
    havanCats.innerHTML = "";
    GIFT_CATEGORIES.forEach(function (c) {
      var d = document.createElement("div");
      d.className = "row";
      d.innerHTML =
        '<span class="circ">' + icon(c.icon) + "</span>" +
        '<span class="txt"><strong>' + c.name + "</strong><small>" + c.ideas + "</small></span>";
      havanCats.appendChild(d);
    });
  }

  renderChips();
  renderTiles();
  renderHavanCats();

  /* ---------- Lista Havan ---------- */
  var havanBtn = document.getElementById("btn-havan");
  var havanSoon = document.getElementById("havan-soon");
  if (HAVAN_LIST_URL && HAVAN_LIST_URL.trim() !== "") {
    havanBtn.href = HAVAN_LIST_URL.trim();
  } else {
    havanBtn.addEventListener("click", function (e) {
      e.preventDefault();
      havanSoon.hidden = false;
    });
  }

  /* ---------- WhatsApp: confirmar presença ---------- */
  var btnWhats = document.getElementById("btn-whats");
  btnWhats.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(WHATSAPP_MESSAGE);
  btnWhats.addEventListener("click", function () { waClicked = true; });
  document.getElementById("msg-preview").textContent = "“" + WHATSAPP_MESSAGE + "”";

  /* ---------- Lembrete ---------- */
  var startDate = new Date(EVENT_DATE_ISO);
  var endDate = new Date(startDate.getTime() + EVENT_DURATION_HOURS * 3600000);

  function icsDate(d) { return d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, ""); }
  function icsEsc(s) { return String(s).replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n"); }

  var details = "Chá de Casa Nova de Damaris e Lucas. Local: " + EVENT_ADDRESS + ". Como chegar: " + mapsLink;

  function buildIcs() {
    var now = icsDate(new Date());
    var lines = [
      "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Cha de Casa Nova//PT-BR//", "CALSCALE:GREGORIAN", "METHOD:PUBLISH",
      "BEGIN:VEVENT",
      "UID:cha-casa-nova-" + icsDate(startDate) + "@cha-casa-nova",
      "DTSTAMP:" + now,
      "DTSTART:" + icsDate(startDate),
      "DTEND:" + icsDate(endDate),
      "SUMMARY:" + icsEsc(EVENT_TITLE),
      "LOCATION:" + icsEsc(EVENT_ADDRESS),
      "DESCRIPTION:" + icsEsc(details),
      "BEGIN:VALARM", "TRIGGER:-P1D", "ACTION:DISPLAY", "DESCRIPTION:" + icsEsc("Amanhã é o chá de casa nova de Damaris e Lucas, às 16h!"), "END:VALARM",
      "BEGIN:VALARM", "TRIGGER:-PT2H", "ACTION:DISPLAY", "DESCRIPTION:" + icsEsc("Daqui a 2 horas começa o chá de casa nova de Damaris e Lucas!"), "END:VALARM",
      "END:VEVENT", "END:VCALENDAR"
    ];
    return lines.join("\r\n");
  }

  document.getElementById("btn-ics").addEventListener("click", function () {
    try {
      var blob = new Blob([buildIcs()], { type: "text/calendar;charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = "cha-de-casa-nova.ics";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      toast("Abra o arquivo para salvar no calendário.");
    } catch (e) {
      toast("Não foi possível gerar o lembrete. Use o Google Agenda.");
    }
  });

  document.getElementById("btn-gcal").href =
    "https://calendar.google.com/calendar/render?action=TEMPLATE" +
    "&text=" + encodeURIComponent(EVENT_TITLE) +
    "&dates=" + icsDate(startDate) + "/" + icsDate(endDate) +
    "&location=" + q +
    "&details=" + encodeURIComponent(details);

  var remindText =
    "Lembrete 💛 Chá de Casa Nova de Damaris e Lucas: sábado, 05/12/2026, às 16h.\n" +
    "Local: " + EVENT_ADDRESS + "\nComo chegar: " + mapsLink;
  document.getElementById("btn-remind-wa").href = "https://wa.me/?text=" + encodeURIComponent(remindText);

  function refreshReminder() {
    var now = new Date();
    var diff = startDate - now;
    var n, l;
    if (diff > 0) {
      var days = Math.floor(diff / 86400000);
      if (days >= 1) { n = days; l = days === 1 ? "dia para o chá" : "dias para o chá"; }
      else { var hrs = Math.max(1, Math.ceil(diff / 3600000)); n = hrs; l = hrs === 1 ? "hora para o chá" : "horas para o chá"; }
    } else if (now < endDate) {
      n = "Hoje"; l = "é o dia do nosso chá!";
    } else {
      n = "💛"; l = "o chá já aconteceu";
    }
    document.getElementById("count-n").textContent = n;
    document.getElementById("count-l").textContent = l;
    document.getElementById("rem-title").textContent = confirmed ? "Mensagem enviada!" : "Quase tudo pronto!";
    document.getElementById("rem-text").textContent = confirmed
      ? "Agora salve o lembrete no seu celular para não esquecer o chá."
      : "Se ainda não enviou a confirmação, volte ao passo anterior. Depois salve o lembrete no seu celular.";
  }

  /* ---------- Início ---------- */
  refreshResume();
  show(currentId());
})();
