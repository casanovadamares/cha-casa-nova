/* =====================================================
   CONFIGURAÇÕES EDITÁVEIS
   Altere apenas os valores entre aspas.
   ===================================================== */

// Estilo da 1ª tela:
//   "classica" = igual à imagem de referência (VOCÊ ESTÁ CONVIDADO(A), letra cursiva)
//   "casa"     = convite com telhado e casinha da data
const COVER_STYLE = "classica";

// Link da lista de presentes da Havan.
// Enquanto estiver vazio (""), o site mostra "lista disponível em breve".
// Exemplo: const HAVAN_LIST_URL = "https://www.havan.com.br/lista/seu-link";
const HAVAN_LIST_URL = "";

// WhatsApp para confirmação (formato internacional, só números, sem + e sem espaços)
const WHATSAPP_NUMBER = "5519983243209";

// Mensagem pré-preenchida da confirmação
const WHATSAPP_MESSAGE =
  "Olá, Damaris e Lucas! 💛 Gostaria de confirmar minha presença no chá de casa nova do dia 05/12/2026, às 16h.";

// Endereço do evento (usado no Google Maps, na rota e no botão de copiar)
const EVENT_ADDRESS =
  "Rua Doroti Martins Fortuna, 70, Condomínio Bem Morar / Novo Horizonte 5, Moradas do Vale, Campinas/SP";

// Categorias de ideias de presentes (nome, ícone e exemplos). Pode editar os exemplos.
const GIFT_CATEGORIES = [
  { id: "cama",  chip: "Cama e banho",  name: "Cama e banho",          icon: "i-bed",   ideas: "Lençóis, edredons, toalhas, tapetes" },
  { id: "mesa",  chip: "Mesa e cozinha", name: "Mesa e cozinha",        icon: "i-fork",  ideas: "Aparelhos de jantar, copos, talheres, jogos americanos" },
  { id: "util",  chip: "Utensílios",     name: "Utensílios domésticos", icon: "i-pot",   ideas: "Panelas, eletroportáteis, utensílios" },
  { id: "org",   chip: "Organização",    name: "Organização da casa",   icon: "i-box",   ideas: "Caixas, cestos, prateleiras" },
  { id: "cafe",  chip: "Café da manhã",  name: "Café da manhã",         icon: "i-cup",   ideas: "Cafeteiras, xícaras, potes" },
  { id: "limp",  chip: "Limpeza",        name: "Limpeza e lavanderia",  icon: "i-spray", ideas: "Cestos de roupa, varais, baldes" }
];

// Data e hora do evento (com fuso de Brasília). Usada na contagem regressiva e no lembrete do calendário.
const EVENT_DATE_ISO = "2026-12-05T16:00:00-03:00";

// Duração do evento em horas (só para o calendário do convidado). Ajuste se quiser.
const EVENT_DURATION_HOURS = 3;

// Título do evento no calendário
const EVENT_TITLE = "Chá de Casa Nova · Damaris e Lucas";
